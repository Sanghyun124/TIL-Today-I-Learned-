<template>
  <div class="h-100 d-inline-block d-flex flex-column justify-content-between align-items-center">
    <br>
    <h2>2단계</h2>
    <br>
    <img class="main" alt="Vue logo" src="../assets/ssafleaf.png">
    <br>
    <h2>싸플리프</h2>
    <br>
  </div>
</template>

<script>
export default {
    name:'ssafLeaf'
}
</script>

<style>

</style>