<template>
  <div class="h-100 d-inline-block d-flex flex-column justify-content-between align-items-center">
    <br>
    <h2>시작</h2>
    <img class="main" alt="Vue logo" src="../assets/ssanocolor.png">
    <h2>싸플링(무색)</h2>
    <br>
  </div>
</template>

<script>
export default {
    name:'noColor'
}
</script>

<style>

</style>