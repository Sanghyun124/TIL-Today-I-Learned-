<template>
<div class="d-flex flex-column justify-content-center">
  <h2>Start 버튼으로 시작해 보세요!</h2>
  <img alt="Vue logo" src="../assets/ssafy-banner.png">
</div>
</template>

<script>
export default {
    name:'ssafyHome'
}
</script>

<style>

</style>